package io.github.l1692.gamenight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameNightApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameNightApplication.class, args);
	}

}
